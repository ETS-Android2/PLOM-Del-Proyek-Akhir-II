package kelompok7.i.user.modelAsrama;

public class AsramaData {
    private int id_aturan;
    private String judul,deskripsi,poin;

    public int getId_aturan() {
        return id_aturan;
    }

    public void setId_aturan(int id_aturan) {
        this.id_aturan = id_aturan;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getPoin() {
        return poin;
    }

    public void setPoin(String poin) {
        this.poin = poin;
    }
}
